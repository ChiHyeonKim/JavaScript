document.writeln('src 속성에 기술된 외부 스크립트에 의한 출력입니다.<br/>');
document.writeln('안녕하세요! 자바스크립트입니다!<br/>');
